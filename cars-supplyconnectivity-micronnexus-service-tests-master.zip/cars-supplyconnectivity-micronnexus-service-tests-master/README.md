# cars-supplyconnectivity-micronnexus-service-tests
Cars Test automation for MicronnexusSCS
