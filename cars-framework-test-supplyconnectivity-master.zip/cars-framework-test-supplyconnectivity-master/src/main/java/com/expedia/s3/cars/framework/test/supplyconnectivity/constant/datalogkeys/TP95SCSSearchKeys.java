package com.expedia.s3.cars.framework.test.supplyconnectivity.constant.datalogkeys;

/**
 * Created by v-mechen on 7/2/2017.
 */
public class TP95SCSSearchKeys extends TP95SCSKeys {
    public static final String SEARCHCRITERIACOUNT = "SearchCriteriaCount";
    public static final String DOWNSTREAMTICALLELAPSEDTIME_REQUEST1 = "DownstreamTiCallElapsedTime_Request_TVAR__1";
    public static final String DOWNSTREAMMNCALLELAPSEDTIME_REQUEST1 = "DownstreamMNCallElapsedTime_Request_VAR__1";
    public static final String DOWNSTREAMWSCSCALLELAPSEDTIME_REQUEST1 = "DownstreamUApiCallElapsedTime_Request_VSAR__1";
}
