package com.expedia.s3.cars.framework.test.supplyconnectivity.constant.datalogkeys;

/**
 * Created by v-mechen on 7/2/2017.
 */
public class TP95SCSReserveKeys extends TP95SCSKeysExceptSearch {
    public static final String WASCCREQUIRED = "WasCCRequired";
    public static final String PAYMENTTYPE = "PaymentType";
}
