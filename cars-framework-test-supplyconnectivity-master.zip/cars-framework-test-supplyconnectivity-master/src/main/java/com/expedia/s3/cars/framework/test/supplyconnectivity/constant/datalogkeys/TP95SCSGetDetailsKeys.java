package com.expedia.s3.cars.framework.test.supplyconnectivity.constant.datalogkeys;

/**
 * Created by v-mechen on 7/2/2017.
 */
public class TP95SCSGetDetailsKeys extends TP95SCSKeysExceptSearch {
    public static final String POLICYCATEGORYCOUNT = "PolicyCategoryCount";
}
