# cars-framework-test-supplyconnectivity
