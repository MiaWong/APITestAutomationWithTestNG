package com.expedia.s3.cars.framework.test.common.dataaccess.dbimpl.carsinventory;

public class CarRentalAmountCalculation
{
    private String vendorCollectsFlag;

    public String getVendorCollectsFlag()
    {
        return vendorCollectsFlag;
    }

    public void setVendorCollectsFlag(String vendorCollectsFlag)
    {
        this.vendorCollectsFlag = vendorCollectsFlag;
    }
}
