package com.expedia.s3.cars.framework.test.common.constant.datalogkeys;

/**
 * Created by fehu on 8/23/2017.
 */
public class DataLogKeys_ErrorAnalysis {
    public static final String ERRORRETURNCODE = "ErrorReturnCode";
    public static final String ERRORTEXT = "ErrorText";
    public static final String DOWNSTREAMMESSAGETYPE = "DownstreamMessageType";
    public static final String TPID = "TPID";
    public static final String TUID = "TUID";
    public static final String POSJURISDICTION = "POSJurisdiction";
    public static final String POSMANAGEMENTUNIT = "POSManagementUnit";
    public static final String POSCOMPANY = "POSCompany";
    public static final String REQUESTSUPPLIERIDS = "RequestSupplierIDs";
    public static final String FIELDXPATH = "FieldXPath";
}
