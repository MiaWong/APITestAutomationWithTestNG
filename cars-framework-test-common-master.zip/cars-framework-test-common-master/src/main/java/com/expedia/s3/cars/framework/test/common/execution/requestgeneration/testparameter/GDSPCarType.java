package com.expedia.s3.cars.framework.test.common.execution.requestgeneration.testparameter;

/**
 * Created by v-mechen on 9/9/2018.
 */
@SuppressWarnings("PMD")
public enum GDSPCarType {
    GDSPCommission,
    GDSPNetRate;

}
