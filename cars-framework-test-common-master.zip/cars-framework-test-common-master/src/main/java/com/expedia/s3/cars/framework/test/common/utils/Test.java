package com.expedia.s3.cars.framework.test.common.utils;

/**
 * Created by yyang4 on 1/4/2017.
 */
@SuppressWarnings("PMD")
public class Test {
    public static void main(String args[]){
        System.out.println(String.format("The actual =%s is not equal the expect =%s .\r\n",1,2));
    }
}
