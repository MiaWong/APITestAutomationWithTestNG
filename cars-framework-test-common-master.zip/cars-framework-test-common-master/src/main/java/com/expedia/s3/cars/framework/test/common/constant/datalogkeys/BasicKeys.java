package com.expedia.s3.cars.framework.test.common.constant.datalogkeys;

/**
 * Created by v-mechen on 7/2/2017.
 */
public class BasicKeys {
    public static final String ORIGINATINGGUID = "OriginatingGUID";
    public static final String ACTIONTYPE = "ActionType";
    public static final String LOGTYPE = "LogType";
}


