package com.expedia.s3.cars.framework.test.common.dataaccess.dbimpl.carsinventory;

/**
 * Created by asharma1 on 9/26/2016.
 */
public class ServiceProvider
{
    private int supplyConnectivityServiceID;

    public int getSupplyConnectivityServiceID() {
        return supplyConnectivityServiceID;
    }

    public void setSupplyConnectivityServiceID(int supplyConnectivityServiceID) {
        this.supplyConnectivityServiceID = supplyConnectivityServiceID;
    }
}
