package com.expedia.s3.cars.supplyconnectivity.titanium.service.tests.utilities.constant;

/**
 * Created by v-mechen on 1/16/2017.
 */
public class POSConfigSettingName {
    public static final String RULES_SETPOLICYCATEGORYTOMERCHANTRULES_ENABLE = "Rules.setPolicyCategoryToMerchantRules/enable";


}

