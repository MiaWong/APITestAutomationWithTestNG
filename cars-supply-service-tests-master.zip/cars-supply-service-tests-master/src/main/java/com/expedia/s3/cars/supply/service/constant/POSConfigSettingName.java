package com.expedia.s3.cars.supply.service.constant;

/**
 * Created by v-mechen on 1/16/2017.
 */
public class POSConfigSettingName {
    public static final String GETDETAILS_USEMERCHANTRULESFROMDETAILSRESPONSE_ENABLE = "GetDetails.useMerchantRulesFromDetailsResponse/enable";
    public static final String GETDETAILS_USEMERCHANTRULESFROMDETAILSRESPONSE_SUPPORTEDSCSIDS = "GetDetails.useMerchantRulesFromDetailsResponse/supportedScsIDs";

}

