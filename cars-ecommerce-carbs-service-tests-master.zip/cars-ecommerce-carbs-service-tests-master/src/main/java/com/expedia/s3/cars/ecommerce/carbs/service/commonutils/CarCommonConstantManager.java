package com.expedia.s3.cars.ecommerce.carbs.service.commonutils;

/**
 * Created by fehu on 8/31/2016.
 */
public class CarCommonConstantManager {

    public static final int PACKAGE = 1;
    public static final int STANDALONE = 0;
    public static final  int ABACUSEXPERIMENTID = 1000;
    public static final  int ABACUSTREATMENTGROUPID = 3000;
    public static final  int ABACUSEXPERIMENTVALUE = 2000;
    public static final String FIRST = "first";
    public static final String SECOND = "Second";
    public static final String ONE_FX936 = "1FX936";
    public static final String QGPDJ8 = "QGPDJ8";
    public static final String W0DFCJ = "W0DFCJ";
    public static final String S7JWZD = "S7JWZD";
    public static final String ZERO_Q7XRN = "0Q7XRN";
    public static final String RT348B = "RT348B";
    public static final String ZCS52L = "ZCS52L";

}
