package expedia.om.supply.messages.defn.v1;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by asharma1 on 11/4/2016.
 */
@XmlRootElement(namespace = "urn:expedia:om:supply:messages:defn:v1", name = "GetOrderProcessRequest")
public class GetOrderProcessRequest extends GetOrderProcessRequestType
{
}
