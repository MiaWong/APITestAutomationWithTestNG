package expedia.om.supply.messages.defn.v1;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by fehu on 11/7/2016.
 */
@XmlRootElement(namespace = "urn:expedia:om:supply:messages:defn:v1", name = "RollbackPreparePurchaseRequest")
public class RollbackPreparePurchaseRequest extends  RollbackPreparePurchaseRequestType{
}
