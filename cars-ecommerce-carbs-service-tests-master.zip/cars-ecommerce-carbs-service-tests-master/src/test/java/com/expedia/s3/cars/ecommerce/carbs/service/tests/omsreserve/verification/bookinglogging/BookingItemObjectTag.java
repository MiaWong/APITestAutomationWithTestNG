package com.expedia.s3.cars.ecommerce.carbs.service.tests.omsreserve.verification.bookinglogging;

/**
 * Created by v-mechen on 9/5/2018.
 */
public class BookingItemObjectTag {

    public static final String CANCELDATE = "cancelDate";
    public static final String CREATEDATE = "createDate";
    public static final String UPDATEDATE = "updateDate";
    public static final String BOOKDATE = "bookDate";
    public static final String SUPPLIERBOOKINGCONFIRMATIONDATE = "supplierBookingConfirmationDate";

}
