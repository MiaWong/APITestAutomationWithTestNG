package com.expedia.s3.cars.ecommerce.carbs.service.tests.omsreserve.verification.bookinglogging;

/**
 * Created by v-mechen on 9/5/2018.
 */
public class BookingAmountObjectTag {

    public static final String BOOKINGAMOUNTSEQNBR = "bookingAmountSeqNbr";
    public static final String CREATEDATE = "createDate";
    public static final String BOOKINGAMOUNTROWGUID = "bookingAmountRowGUID";

}
