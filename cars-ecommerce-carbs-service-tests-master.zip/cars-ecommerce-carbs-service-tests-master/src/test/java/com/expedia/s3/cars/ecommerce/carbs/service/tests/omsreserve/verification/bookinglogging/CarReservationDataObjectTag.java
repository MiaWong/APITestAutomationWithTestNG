package com.expedia.s3.cars.ecommerce.carbs.service.tests.omsreserve.verification.bookinglogging;

/**
 * Created by v-mechen on 9/5/2018.
 */
public class CarReservationDataObjectTag {

    public static final String CREATEDATE = "createDate";
    public static final String CARRESERVATIONNODEDATA = "carReservationNodeData";
}
