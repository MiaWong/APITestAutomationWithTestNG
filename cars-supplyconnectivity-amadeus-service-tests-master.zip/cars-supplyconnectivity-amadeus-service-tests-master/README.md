# cars-supplyconnectivity-amadeus-service-tests
Functional tests for Amadeus SCS (cars-supplyconnectivity-amadeus-service)
